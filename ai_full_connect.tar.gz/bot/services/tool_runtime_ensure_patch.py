"""Optional import: call ensure before listing/executing tools.

Import this from tool_runtime facade if needed. Also safe to call from
get_tool_definitions / execute_tool wrappers.
"""
from bot.services.capability_autoload import ensure_all_capabilities_registered

def before_tools():
    ensure_all_capabilities_registered()
