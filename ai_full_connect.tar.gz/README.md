# وصل کامل قابلیت‌های ربات به هوش مصنوعی + اتصال خودکار قابلیت جدید

## فایل‌های جدید / جایگزین

| فایل | کار |
|------|-----|
| `bot/services/capability_autoload.py` | **جدید** — کشف خودکار + دکوریتور `@ai_tool` |
| `bot/services/ai_full_bridge.py` | **جدید** — وصل همه قابلیت‌های قبلی که tool نداشتند |
| `bot/services/ai_tools.py` | **جایگزین** — بعد از لود، `ensure_all_capabilities_registered()` |
| `bot/services/tool_runtime.py` | **جایگزین** — قبل از list/execute tool دوباره ensure |
| `bot/services/current_datetime.py` | فیکس تاریخ (relative_day) |
| `bot/services/ai_freshness.py` | فیکس تاریخ + SYSTEM CLOCK |
| `bot/services/ai_service_parts/part_999_core_legacy.py` | system prompt آگاه از اتصال کامل |

## نصب

```bash
cd /path/to/ALIMJ3
cp path/to/ai_full_connect/bot/services/capability_autoload.py bot/services/
cp path/to/ai_full_connect/bot/services/ai_full_bridge.py bot/services/
cp path/to/ai_full_connect/bot/services/ai_tools.py bot/services/
cp path/to/ai_full_connect/bot/services/tool_runtime.py bot/services/
cp path/to/ai_full_connect/bot/services/current_datetime.py bot/services/
cp path/to/ai_full_connect/bot/services/ai_freshness.py bot/services/
cp path/to/ai_full_connect/bot/services/ai_service_parts/part_999_core_legacy.py bot/services/ai_service_parts/
# ری‌استارت ربات
```

## قابلیت‌های تازه‌وصل‌شده به AI

- profit_loss (سود و ضرر)
- analyze_gold (تحلیل طلا)
- date_diff / age_diff
- custom_countdown
- list_reminders / cancel_reminder
- add_note / list_notes / delete_note
- save_birth_date / user_stats
- set_user_city / set_user_language
- get_azan_settings / set_azan
- joke_categories
- download_media
- generate_image / prepare_tts
- list_ai_capabilities

## قابلیت جدید بعداً چطور خودکار وصل شود؟

```python
# مثلاً bot/features/myfeature/ai_bind.py
from bot.services.capability_autoload import ai_tool

@ai_tool(
    name="my_new_feature",
    description="توضیح برای مدل",
    parameters={"type": "object", "properties": {"q": {"type": "string"}}},
    keywords=[r"کلمه.?کلیدی"],
)
def my_new_feature(q: str = "", user_id: int = 0) -> str:
    return "نتیجه"
```

یا لیست:

```python
__ai_tools__ = [{
    "name": "my_new_feature",
    "description": "...",
    "handler": my_new_feature,
    "parameters": {...},
    "keywords": [...],
}]
```

با ری‌استارت (یا اولین فراخوانی tool) خودکار در رجیستری AI ثبت می‌شود.

## تست در چت

- چه کارهایی می‌تونی؟
- تحلیل طلا
- سود و ضرر خرید ۱۰۰ فروش ۱۲۰ تعداد ۲
- یادداشت کن: خرید شیر
- اذان صبح را روشن کن
- اختلاف تاریخ 1400/01/01 و 1403/07/15
